#!/bin/bash

# Source function library.
#. /etc/rc.d/init.d/functions

PWD=$(pwd)
basename=$0
echo  $basename


function check_installed()
{
    local software=$1
    rpm -q --quiet ${software}
#    dpkg -l gcc |grep gcc |awk '{print $3}'|grep -Ev "<无>"
    return $?
}

# install python2.7
function install_python2.7()
{
    yum -y install unzip zip   make zlib zlib-devel 
    yum -y install openssl-devel bzip2-devel expat-devel gdbm-devel readline-devel sqlite-devel gcc gcc-c++  openssl-devel
    tar xf Python-2.7.15.tgz
    cd Python-2.7.15
    ./configure --prefix=/usr/local/python2.7
    make 
    make install
    cd -
 #   mv /usr/bin/python /usr/bin/pythonbak
    ln -s /usr/local/python2.7/bin/python2.7 /usr/bin/python2.7
}

# install setuptools
function install_setuptools()
{
   unzip setuptools-39.2.0.zip
   cd setuptools-39.2.0
   /usr/bin/python2.7 setup.py install
   cd -
}


function install_pip()
{
#    yum install -y gcc gcc++ make
   # check_installed python-setuptools
   # if [ $? -ne 0 ];then
   #     echo "yum installing python-setuptoos"
   #     yum -y install python-setuptools 
   # else
   #     echo "python-setuptoos installed"
   # fi
    tar xf $PWD/pip-10.0.1.tar.gz
    cd pip-10.0.1
    echo "installing pip"
    /usr/bin/python2.7 setup.py install
    cd -
    ln -s /usr/local/python2.7/bin/pip2.7 /usr/bin/pip2.7
}

#upgrade所需要模块
function install_psutil()
{
    yum install -y build-dep python-lxml 
    yum install -y libxml2-dev libxslt1-dev python-dev
    /usr/bin/pip2.7 install psutil

}

#启动dLR所需要模块
function install_tornado()
{
    pip2.7 install 'tornado <= 4.4.4'
    if [ $? -ne 0 ];then
        echo "installing tornado"
        tar xf $PWD/tornado-4.3.tar.gz
        cd tornado-4.3
        /usr/bin/python2.7 setup.py install
        cd -
    else 
        echo "installing tornado success"
    fi

}

#dLR管理模块
function install_supervisor()
{
    check_installed supervisor
    if [ $? -ne 0 ];then
        #echo "yum installing supervisor"
        #yum -y install supervisor > /dev/null
        #res=$?
        #if [ res -ne 0 ];then
            tar xf meld3-1.0.2.tar.gz
            cd meld3-1.0.2
            python setup.py install
            cd -
            tar xf $PWD/supervisor-3.3.4.tar.gz
            cd supervisor-3.3.4
            python setup.py install
            echo_supervisord_conf > /etc/supervisord.conf
            cd -
        #fi
    fi             
} 

#启动supervisor并加入开机启动
#function start_supervisor()
#{
#    echo -e  "[program:lr9001]\ncommand=$DIR/dLR/run.sh &> /dev/null &\ndirectory=$DIR/dLR\nautostart=true\nautorestart=true\nstartsecs=3\nstartretries=100" >> /etc/supervisord.conf
#    supervisord -c /etc/supervisord.conf
##开机启动supervisor
#    cp $DIR/supervisord /etc/init.d/
#    yum -y install sysv-rc-conf
#    sysv-rc-conf --level 234 supervisord on
#}

function powerboot_run()
{
    chmod +x $PWD/run.sh
    echo -e "cd /$PWD/\n./run.sh\ncd -" >> /etc/rc.d/rc.local
}

#function start_supervisor()
#{
#    cd ../dLR
#    DIR=`pwd`
#    cd -
#    cat /etc/supervisord.conf |grep lr9001
#    res=$?
#    if [ $res -ne "0" ];then
#        echo -e  "[program:lr9001]\ncommand=python dlr.pyc *.*.*.* 9001 &> /dev/null &\ndirectory=$DIR\nautostart=true\nautorestart=true\nstartsecs=3\nstartretries=100" >> /etc/supervisord.conf
#        cp $PWD/supervisord /etc/init.d/supervisord
#        chmod 777 /etc/init.d/supervisord
#        chkconfig --level 2345 supervisord on
#        cd $DIR
#        cat run.sh|grep python
#        res1=$?
#        if [ $res1 -ne "0" ];then
#            echo -e "#!/bin/bash\ncd $DIR\npython dlr.pyc *.*.*.* 9001 &>/dev/null &"
#           cd -
#        fi
#       /etc/init.d/supervisord stop
#       /etc/init.d/supervisord start
#    fi
#    cat /etc/supervisord.conf |grep autoUpgrade.pyc
#    res=$?
#    if [ $res -ne "0" ];then
#        echo -e  "[program:autoUpgrade]\ncommand=python autoUpgrade.pyc &\ndirectory=$DIR\nautostart=true\nautorestart=true\nstartsecs=3\nstartretries=100" >> /etc/supervisord.conf
#    fi
#    cat /etc/supervisord.conf |grep route_map.pyc
#    res=$?
#    if [ $res -ne "0" ];then
#        echo -e  "[program:route_map]\ncommand=python route_map.pyc &\ndirectory=$DIR\nautostart=true\nautorestart=true\nstartsecs=3\nstartretries=100" >> /etc/supervisord.conf
#    fi
#}

install_python2.7
install_setuptools
install_pip
install_psutil
install_tornado
#install_supervisor
#powerboot_run
#start_supervisor
